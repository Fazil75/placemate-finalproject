import React from "react";

function Eligibility() {
  return (
    <div style={{ padding: "2rem" }}>
      <h2 style={{ color: "#6366f1" }}>📑 Job Descriptions & Eligibility</h2>
      <p>Here staff can define eligibility criteria for different jobs.</p>
    </div>
  );
}

export default Eligibility;  // ✅ default export
