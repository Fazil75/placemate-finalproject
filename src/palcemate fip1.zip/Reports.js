import React from "react";

function Reports() {
  return (
    <div style={{ padding: "2rem" }}>
      <h2 style={{ color: "#6366f1" }}>📊 Reports & Analytics</h2>
      <p>View placement statistics and analytics here.</p>
    </div>
  );
}

export default Reports;
