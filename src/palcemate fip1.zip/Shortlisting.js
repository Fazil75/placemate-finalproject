import React from "react";

function Shortlisting() {
  return (
    <div style={{ padding: "2rem" }}>
      <h2 style={{ color: "#6366f1" }}>✅ Student Shortlisting</h2>
      <p>Manage shortlisted students here.</p>
    </div>
  );
}

export default Shortlisting;  // ✅ default export
